// Modified 2026-11-09 for iYT; see licenses/NOTICE.md and docs/audit.md.
'use strict';
/** Native list browser, BMW keyboard handoff, audio/video playback and Park-gated map output. */
const fs = require('fs');
const path = require('path');
const mgu = require('./kit/mgu');
const G = require('./kit/gauges');
const QR = require('./kit/qr');
const { setImage } = require('./kit/record');
const { HMI } = require('./kit/display');
const Parked = require('./kit/parked');
const Brand = require('./brand');
const ClusterVehicle = require('./kit/cluster-vehicle');
const { Ctl, Model, clock, SOCKET, FEEDS, SHELF_MAX } = require('./yt');
const { spell, cancel: cancelSpell } = require('./speller');

const W = 1600, H = 520;
const BOX = { x: 12, y: 38, w: 1576, h: 432 };          // the video, in the page's visible part (y 38..520)
const VID = 1, VPATH = process.env.MGU_YT_VIDEO || '/dev/shm/mgu-video-iyt';     // (env: tests)
const POOL0 = 8, POOL = 56;                               // picture ids POOL0.. for the thumbs drawn (a pool, by video)
const TOP = 38;                                          // the page shows from here down (the kit: y 38..520 + extra)
const RAIL_W = 0;
const OVERLAY_MS = 4000;                                 // the player's controls hide this long after a tap (playing)
const SEARCH_MS = 8000;                                  // a search with no answer by then is an error on screen
const SUGGEST = ['Music', 'News', 'Cars', 'Podcasts', 'Comedy', 'Trailers'];
const SLOTS = ['BTN_S1', 'BTN_S2', 'BTN_S3', 'BTN_S4', 'BTN_S5', 'BTN_S6'];
const TABS = ['home', 'subs', 'wl'];
const NAMES = { home: 'Home', subs: 'Subscriptions', wl: 'Watch later', results: 'Results' };
const FEED_MS = 15000;                                   // a feed with no answer by then is an error on screen
const SIGNIN_URL = 'https://www.google.com/device';

process.on('uncaughtException', (e) => { try { mgu.log.error('uncaught', e); } catch (x) { /* nothing left to log with */ } });

mgu.run({
    async start(ctx) {
        const { ui, settings, log } = ctx;
        const parked = Parked.watch(ctx, log, { strict: true });
        const clusterVehicle = ClusterVehicle.watch(ctx, log);
        // Main-screen (MGU) video is never blocked by speed or gear. Only the cluster video keeps its lock:
        // sync() sends cluster_vehicle park:true only while vehicle.allowed (Park + zero speed, fresh signals).
        const noVideo = () => false;

        /* ---------- the daemon ---------- */
        const ctl = new Ctl(process.env.MGU_YT_SOCKET || SOCKET, log);
        const model = new Model((o) => ctl.send(o));
        let mode = 'home', browse = 'home', dirty = true;   // browse: the list the player goes back to
        let keyboardBusy = false, exited = false, closingViews = false, sawVisible = false, leaveTimer = null;
        const changed = () => { dirty = true; labels(); };
        const appStates = ['VIEW', 'MAIN', 'DIAG', 'SETTINGS'];
        const anyVisible = () => appStates.some((name) => ui.isVisible(name));
        sawVisible = anyVisible();
        function stopPlayback() {
            model.setWantVideo(false);
            ctl.send({cmd: 'cluster_vehicle', park: false});
            ctl.send({cmd: 'display_mode', mode: 'main'});
            ctl.send({cmd: 'video', on: false});
            ctl.send({cmd: 'stop'});
            if (ctx.display && ctx.display.gpu) ctx.display.gpu.dropVideo(VID);
            ino = null; videoShown = false;
            if (ctx.background) ctx.background('playing', false);
        }
        function leaveApp() {
            exited = true;
            if (ctx.display && ctx.display.suspend) ctx.display.suspend('appHidden', true);
            cancelSpell(ctx.app);
            stopPlayback();
            ctl.close();
            if (mode === 'player') mode = browse;
        }
        async function exitApp() {
            closingViews = true;
            clearTimeout(leaveTimer);
            leaveApp();
            if (ctx.display && ctx.display.closeSheet) ctx.display.closeSheet();
            try { for (const name of ['SETTINGS', 'DIAG', 'MAIN', 'VIEW']) { if (ui.isVisible(name)) await ui.close(name); } }
            finally { closingViews = false; }
        }
        function resumeApp() {
            if (closingViews || !exited) return;
            exited = false;
            if (ctx.display && ctx.display.suspend) ctx.display.suspend('appHidden', false);
            ctl.reopen();
        }
        function visibilityChanged(name, on) {
            clearTimeout(leaveTimer);
            if (closingViews) return;
            if (anyVisible()) {
                sawVisible = true;
                if (on === true) resumeApp();
            } else if (sawVisible && !keyboardBusy) {
                leaveTimer = setTimeout(() => { if (!anyVisible() && !keyboardBusy) leaveApp(); }, 500);
            }
        }
        if (ctx.app && ctx.app.on) {
            ctx.app.on('changeVisibility', (v) => {
                if (v && v.visible === false && !keyboardBusy) leaveApp();
                else if (v && v.visible === true) resumeApp();
            });
            ctx.app.on('shutdown', () => leaveApp());
        }
        ui.onVisible(visibilityChanged);
        ctx.signals.watch('de.bmw.infotainment.controlelements.FrontCCU', '1', {
            statusRotaryEncoderState: (v) => { if (ctx.controller && ctx.controller.fallback) ctx.controller.fallback(v); },
        }, log).catch((e) => log.warn('controller fallback: ' + e.message));
        const isFeed = (m) => FEEDS.indexOf(m) >= 0;
        // a feed tab: signed in, (re)load it; signed out, ask for a sign-in code (the daemon says the one shown again).
        // A new device flow starts only from here (show), the account button or the page's "tap" - never on its own
        const openFeed = () => {
            if (!isFeed(mode)) return;
            if (model.auth.state !== 'signed_in') { model.authStart(); return; }
            model.feed(mode);
            if (mode === 'home') model.feed('wl');
            if (mode === 'subs') model.loadChannels();                    // Home's last shelf (one request at a time: idempotent)
        };
        const backKey = {};                              // page -> the tile the controller was on when it was left
        function show(m) {
            if (m !== mode) { dirty = true; if (laid.mode === mode && laid.where[focusKey]) backKey[mode] = focusKey; }   // (a tile of this page)
            mode = m;
            if (m !== 'player') browse = m; else wake();
            openFeed(); sync(); labels();
        }
        function backToBrowse() { stopPlayback(); goBack(browse); }
        function goBack(m) {
            show(m);
            if (backKey[m] && ctx.focus) ctx.focus(backKey[m]);
        }
        ctl.on('up', () => { model.setConnected(true); changed(); });
        ctl.on('down', () => { model.setConnected(false); changed(); });
        ctl.on('msg', (m) => {
            if (m.ev === 'diagnostics') {
                const mb = m.memory ? Math.round(m.memory.rss / 1048576) : null;
                ui.text('DIAG_STATUS', 'iYT ' + m.version + ' | ' + m.node +
                    ' | GPU: ' + m.gpuDevice + ' | acceleration: ' + m.hardwareAcceleration +
                    ' | memory: ' + (mb === null ? 'unavailable' : mb + ' MiB') +
                    ' | output: ' + (settings.get('clusterVideo') ? 'iDrive and cluster map' : 'iDrive') +
                    ' | cluster: ' + ((m.cluster && m.cluster.shown) ? 'showing map video' :
                        (m.cluster && m.cluster.state ? m.cluster.state.status : 'not connected')) +
                    ' | vehicle: ' + clusterVehicle.snapshot().reason +
                    ' | controller: ' + (ctx.display.inputSource || 'no events received') +
                    (m.lastError ? ' | ' + m.lastError.code + ': ' + m.lastError.message : ''));
                const video = (m.mediaFormats || {}).video, audio = (m.mediaFormats || {}).audio;
                ui.text('DIAG_MEDIA', 'Video: ' + (video ? (video.vcodec || 'unknown') + ' ' + (video.width || '?') + 'x' + (video.height || '?') + ' at ' + (video.fps || '?') + ' fps' : 'not reported') +
                    ' | Audio: ' + (audio ? (audio.acodec || 'unknown') + ' (' + (audio.ext || '?') + ')' : 'not reported'));
                ui.text('DIAG_AUDIO', 'BMW MediaPlayer: ' + (m.lastMediaPlayerError ? JSON.stringify(m.lastMediaPlayerError.event).slice(0, 240) : 'no rejection recorded'));
                ui.text('DIAG_DECODER', 'Video decoder: ' + (m.lastDecoderError ? m.lastDecoderError.message : 'no error recorded'));
                return;
            }
            model.onMsg(m);
            if (m.ev === 'error') log.warn('iyt-daemon: ' + m.msg);
            if (m.ev === 'state') log.info('iyt-daemon: ' + m.state + (m.id ? ' ' + m.id : ''));
            if (m.ev === 'auth') { log.info('iyt-daemon: account ' + m.state); if (m.state === 'signed_in') openFeed(); }
            changed();
        });
        ctl.connect();

        /* ---------- hidden channels (a channel page's Hide), members-only videos (a setting) ---------- */
        const HIDDEN = path.join(ctx.dataDir, 'hidden.json');
        let hidden = [];
        try { hidden = JSON.parse(fs.readFileSync(HIDDEN, 'utf8')).filter((s) => typeof s === 'string'); } catch (e) { /* none yet */ }
        function toggleHidden(name) {
            hidden = hidden.indexOf(name) >= 0 ? hidden.filter((x) => x !== name) : hidden.concat(name);
            try { fs.writeFileSync(HIDDEN, JSON.stringify(hidden)); } catch (e) { log.warn('hidden: ' + e.message); }
            dirty = true;
        }
        // what Home, Subscriptions, Watch later and Search show (a channel's own page shows all)
        const shown = (items) => items.filter((r) => hidden.indexOf(r.channel) < 0 && !(r.members && !settings.get('members')));

        /* ---------- searches: recent first, then suggestions ---------- */
        const RECENT = path.join(ctx.dataDir, 'recent.json');
        let recent = [];
        try { recent = JSON.parse(fs.readFileSync(RECENT, 'utf8')).filter((s) => typeof s === 'string').slice(0, SLOTS.length); } catch (e) { /* none yet */ }
        const slots = () => recent.concat(SUGGEST.filter((s) => recent.indexOf(s) < 0)).slice(0, SLOTS.length);
        const showSlots = () => slots().forEach((s, i) => ui.text(SLOTS[i], s));
        function search(q) {
            q = String(q || '').trim();
            if (!q) return;
            recent = [q].concat(recent.filter((s) => s.toLowerCase() !== q.toLowerCase())).slice(0, SLOTS.length);
            try { fs.writeFileSync(RECENT, JSON.stringify(recent)); } catch (e) { log.warn('recent: ' + e.message); }
            showSlots();
            model.search(q);               // (not sent: the results screen says why)
            show('results');
            ui.open('VIEW');
        }
        ui.onClick('BTN_DIAG', () => { ui.open('DIAG'); ctl.send({cmd: 'diagnostics'}); });
        ui.onClick('BTN_DIAG_REFRESH', () => ctl.send({cmd: 'diagnostics'}));
        ui.onClick('BTN_DIAG_BACK', () => ui.open('MAIN'));
        async function openSearch(kind) {
            if (keyboardBusy || exited) return;
            keyboardBusy = true;
            stopPlayback();
            if (ctx.background) ctx.background('keyboard', true);
            if (ctx.display && ctx.display.suspend) ctx.display.suspend('keyboard', true);
            try {
                const text = await spell(ctx.app, kind === 'channel' ? 'Find a channel' : 'Search videos');
                if (!exited) {
                    if (text && text.trim() && kind === 'channel') {
                        chanQ = text.trim(); vs('subs').sy = 0; vs('subs').off = {}; dirty = true;
                        show('subs'); await ui.open('VIEW');
                    } else if (text && text.trim()) search(text);
                    else await ui.open('VIEW');
                }
            } catch (e) {
                log.warn('speller: ' + (e.message || e));
                if (!exited) { await ui.text('MAIN_INFO', 'The keyboard did not open. Select Search to try again.'); await ui.open('MAIN'); }
            } finally {
                keyboardBusy = false;
                if (ctx.background) ctx.background('keyboard', false);
                if (ctx.display && ctx.display.suspend) ctx.display.suspend('keyboard', false);
                dirty = true;
                visibilityChanged();
            }
        }
        const openSettings = () => { stopPlayback(); return ui.open('SETTINGS'); };
        ui.onClick('BTN_SEARCH', openSearch);
        ui.onClick('BTN_MENU_SETTINGS', openSettings);
        ui.onClick('BTN_EXIT', exitApp);
        ui.onClick('BTN_MENU_EXIT', exitApp);
        SLOTS.forEach((b, i) => ui.onClick(b, () => search(slots()[i])));
        ui.onClick('BTN_NOW', () => { show('player'); ui.open('VIEW'); });
        ui.onClick('BTN_RESULTS', () => { show('results'); ui.open('VIEW'); });
        [['BTN_HOME', 'home'], ['BTN_SUBS', 'subs'], ['BTN_WL', 'wl']].forEach(([b, m]) => ui.onClick(b, () => { show(m); ui.open('VIEW'); }));
        // Sign in: the Home tab shows how (after a failed try, asks again). Sign out: pressed twice within 5 s
        let signOutArmed = null;
        ui.onClick('BTN_ACCOUNT', () => {
            if (model.auth.state !== 'signed_in') { show('home'); model.authStart(true); ui.open('VIEW'); return; }
            if (!signOutArmed) { signOutArmed = setTimeout(() => { signOutArmed = null; labels(); }, 5000); labels(); return; }
            clearTimeout(signOutArmed); signOutArmed = null;
            model.signOut();
            labels();
        });
        showSlots();

        function info() {
            let s;
            if (!model.connected) s = 'The iYT service (iyt-daemon) is not running';
            else if (model.searchError) s = 'Search: ' + model.searchError;
            else if (model.error) s = 'Error: ' + model.error;
            else if (model.active()) s = (model.state === 'preparing' ? 'Preparing ' + Math.round(model.pct) + ' %: ' : model.state === 'paused' ? 'Paused: ' : 'Playing: ') + model.title;
            else s = 'Search, or pick a recent search below';
            ui.text('MAIN_INFO', s);
        }
        info();
        setInterval(() => { try { model.checkSearch(Date.now(), SEARCH_MS); model.checkFeeds(Date.now(), FEED_MS); if (ui.isVisible('MAIN')) info(); } catch (e) { log.error('info', e); } }, 1000);

        /* ---------- playing ---------- */
        // the decoder's picture size. Full-screen layout: the whole screen, for the full view (ytdec fits, or
        // fills when that crops at most 15 %; the fill setting, on by default, always crops); the player draws the same frame
        // smaller (op 19 fits it into its box). The daemon has no rect change, so the size is the full view's
        // from the start. Else the box in screen pixels.
        function rect() {
            const pl = ctx.display && ctx.display.place, s = (pl && pl.scale) || 1;
            const even = (v, max) => Math.min(max, Math.max(16, Math.round(v / 2) * 2));
            if (pl && pl.full) return even(pl.w, 2048) + 'x' + even(pl.h, 2048);
            return even(BOX.w * s, 1920) + 'x' + even(BOX.h * s, 720);
        }
        // it: the tile tapped (its title and channel show while the video is prepared)
        // list: the row it was picked from; the videos after it play next when one ends (autoplay)
        const QUALITIES = ['auto', '720', '480', '360'];   // app.json's Video quality values, in the button's order
        let queue = [], nextAt = 0;
        function play(id, it, list) {
            show('player');
            if (list) { const i = list.findIndex((r) => r.id === id); queue = list.slice(i + 1).filter((r) => r && !r.act && /^[\w-]{11}$/.test(r.id)); }
            nextAt = 0;
            if (model.id === id && model.active()) return;
            model.play(id, rect(), settings.get('fill') !== false, it, { quality: settings.get('quality'), skip: sbSkip() });
        }
        // from render: ended with a next one -> 5 s to see what comes, then it plays (back to the list cancels)
        function autoNext() {
            if (model.state !== 'ended' || !queue.length || mode !== 'player') { nextAt = 0; return null; }
            if (!nextAt) { nextAt = Date.now() + 5000; wake(); }
            if (Date.now() < nextAt) return queue[0];
            const r = queue.shift();
            play(r.id, r);
            return null;
        }
        let lastPlay = null, lastList = null, lastAcct = null;
        function labels() {
            const p = model.state === 'playing' ? 'Pause' : 'Play';
            if (p !== lastPlay) { lastPlay = p; ui.text('BTN_PLAY', p); }
            const l = mode === 'player' ? NAMES[browse] : model.active() ? 'Now playing' : 'Player';
            if (l !== lastList) { lastList = l; ui.text('BTN_LIST', l); }
            const a = model.auth.state !== 'signed_in' ? 'Sign in' : signOutArmed ? 'Press again to sign out' : 'Sign out';
            if (a !== lastAcct) { lastAcct = a; ui.text('BTN_ACCOUNT', a); }
        }
        ui.onClick('BTN_PLAY', () => model.toggle());
        ui.onClick('BTN_RW', () => model.skip(-10000));
        ui.onClick('BTN_FF', () => model.skip(10000));
        ui.onClick('BTN_LIST', () => show(mode === 'player' ? browse : 'player'));
        if (ctx.onTab) ctx.onTab((i) => { if (TABS[i]) show(TABS[i]); });
        ui.onClick('BTN_FIND', openSearch);
        ui.onClick('BTN_MENU', () => ui.open('MAIN'));
        // where the kit runs the screen: no bar at all (the rail and the player's overlay do its jobs), so the
        // pages reach the screen's bottom; the HMI's own screen keeps all five
        if (ctx.hideButton) ['BTN_PLAY', 'BTN_RW', 'BTN_FF', 'BTN_LIST', 'BTN_FIND', 'BTN_SETTINGS', 'BTN_EXIT', 'BTN_MENU'].forEach((b) => ctx.hideButton(b, true));
        labels();

        /* ---------- the player's overlay (where the kit runs the screen): shown on a tap or the controller ---------- */
        // the knob turned on the progress bar: 10 s a detent, one seek once it rests 350 ms (the bar moves at once)
        let pend = 0, pendT = null;
        function turnSeek(d) {
            if (model.state !== 'playing' && model.state !== 'paused') return;
            pend += d * 10000; wake();
            clearTimeout(pendT);
            pendT = setTimeout(() => { const ms = pend; pend = 0; model.skip(ms); dirty = true; }, 350);
        }
        const shownAt = () => Math.max(0, Math.min(model.total > 0 ? model.total : Infinity, model.elapsed + pend));
        // preparing: its percentage, or the network lost and the daemon trying again
        const prepText = () => (model.retry ? 'No connection - trying again (' + model.retry + ')...' : 'Preparing... ' + Math.round(model.pct || 0) + ' %');
        // a failed play: Try again (the same video, the queue kept)
        const again = () => { if (model.id) play(model.id, model.item(model.id)); };
        /* ---------- SponsorBlock: per category Skip, a Skip button (ask) or Off (Settings) ---------- */
        const SB = [['sponsor', 'sponsor'], ['selfpromo', 'self-promotion'], ['interaction', 'subscribe reminder'], ['intro', 'intro'], ['outro', 'end cards'], ['music_offtopic', 'non-music part']];
        const sbMode = (cat) => settings.get('sb_' + cat) || 'off';
        const sbSkip = () => SB.map((c) => c[0]).filter((c) => sbMode(c) === 'skip');
        const sbName = (cat) => (SB.find((c) => c[0] === cat) || [0, 'segment'])[1];
        const sbSegs = (ex) => ex.segments.filter((g) => sbMode(g[2]) !== 'off');
        const sbColor = (g) => (sbMode(g[2]) === 'ask' ? '#ffd400' : '#00d400');
        // the segment the clock is in whose category asks: its Skip button shows (and the overlay stays)
        function askSeg() {
            const ex = model.extras && model.extras.id === model.id ? model.extras : null, t = shownAt();
            if (!ex || (model.state !== 'playing' && model.state !== 'paused')) return null;
            return ex.segments.find((g) => sbMode(g[2]) === 'ask' && t >= g[0] && t < g[1] - 1000) || null;
        }
        const sbJump = (g) => () => model.skip(g[1] - shownAt());

        /* ---------- the 12 V battery while parked: a warning 5 points above the setting's level, paused below it ---------- */
        let soc = null, socWarned = false;
        Promise.resolve(ctx.signals.watch('de.bmw.infotainment.vehicle.CDS', '1', {
            statusBattery2: (v) => { const k = v && v.conditionBatteryChargingCondition; if (typeof k === 'number' && k > 0 && k <= 100) soc = k; },
        }, log, { pollMs: 10000 })).catch((e) => log.warn('battery: ' + e));
        function batteryGuard() {
            const lim = Number(settings.get('battery'));
            if (!lim || soc === null) return;
            if (soc >= lim + 5) socWarned = false;
            if (parked.moving() || model.state !== 'playing') return;          // driving charges it
            if (soc < lim) {
                model.toggle();
                model.toast = { text: '12 V battery at ' + soc + ' % - paused. Start the car to keep watching', until: Date.now() + 15000, warn: true };
            } else if (soc < lim + 5 && !socWarned) {
                socWarned = true;
                model.toast = { text: '12 V battery at ' + soc + ' % - it pauses at ' + lim + ' %', until: Date.now() + 8000, warn: true };
            } else return;
            wake(); changed();
        }
        setInterval(() => { try { batteryGuard(); } catch (e) { log.error('battery', e); } }, 1000);
        let ovUntil = 0, qrUntil = 0;   // qrUntil: the On phone QR card shows until then
        function wake() { ovUntil = Date.now() + OVERLAY_MS; dirty = true; }
        // it stays while there is no moving picture to look at
        const pinned = () => model.state !== 'playing' || !videoShown || noVideo() || !!askSeg();
        const overlay = () => pinned() || Date.now() < ovUntil || Date.now() < qrUntil;
        // a tap beside the controls (no target): hides them
        if (ctx.onTap) ctx.onTap(() => { if (mode === 'player' && !pinned() && overlay()) { ovUntil = 0; dirty = true; } });
        // the controller pushed left in the player: back to the list it came from; pushed left at a channel's
        // edge (the rail): back to Subscriptions. Both put the controller back on the tile it left from
        if (ctx.onBack) ctx.onBack((edge) => {
            if (mode === 'player') { backToBrowse(); return true; }
            if (mode === 'channel' && edge) { goBack(chanFrom); return true; }
            return false;
        });

        /* ---------- video gate: on screen and parked; else off (sound plays on) ---------- */
        let ino = null, videoShown = false;
        const gpu = () => (ctx.display && ctx.display.gpu && ctx.display.gpu.native ? ctx.display.gpu : null);
        function sync() {
            const shown = ui.isVisible('VIEW') && (!ui.hasFocus || ui.hasFocus('VIEW'));
            const want = !exited && !keyboardBusy && mode === 'player' && shown && !noVideo();
            const vehicle = clusterVehicle.snapshot();
            ctl.send({cmd: 'display_mode', mode: settings.get('clusterVideo') ? 'dual' : 'main'});
            ctl.send({cmd: 'cluster_vehicle', park: !!(want && settings.get('clusterVideo') && vehicle.allowed),
                speed: vehicle.speed, expiresAt: vehicle.expiresAt});
            model.setWantVideo(want);
            // the file ytdec writes; a new one (ytdec restarted) is named to the renderer again
            let cur = null;
            if (want && (model.state === 'playing' || model.state === 'paused')) {
                try { const st = fs.statSync(VPATH); cur = st.isFile() ? st.ino : null; } catch (e) { cur = null; }
            }
            const g = gpu();
            if (g) {
                if (!cur || cur !== ino) g.dropVideo(VID);
                if (cur) g.video(VID, VPATH);
            }
            ino = cur;
            const on = !!(cur && g);
            if (on !== videoShown) { videoShown = on; dirty = true; }
        }
        setInterval(() => { try { sync(); } catch (e) { log.error('sync', e); } }, 250);
        ui.onVisible((name, v) => { if (name === 'VIEW') { sync(); dirty = true; } });
        if (ui.onFocus) ui.onFocus(() => sync());
        if (ctx.onLayout) ctx.onLayout(() => { dirty = true; });

        /* ---------- drawing ---------- */
        const fit = (cv, s, size, w, opts) => {
            s = String(s || '');
            if (cv.textWidth(s, size, opts) <= w) return s;
            let lo = 0, hi = s.length;
            while (lo < hi) { const m = (lo + hi + 1) >> 1; if (cv.textWidth(s.slice(0, m) + '…', size, opts) <= w) lo = m; else hi = m - 1; }
            return s.slice(0, lo).replace(/\s+$/, '') + '…';     // (no trimEnd on the unit's Node 8)
        };
        const LIT = { literal: true }, LITB = { literal: true, font: 'bold' };
        const C = require('./theme');
        const browsing = () => mode !== 'player';

        // thumbs: a pool of picture ids by video, least recently drawn reused (the renderer holds 64 pictures an app)
        const pool = new Map(), free = Array.from({ length: POOL }, (_, i) => POOL0 + i);
        let frameNo = 0;
        function slot(id, th) {
            let e = pool.get(id);
            if (!e) {
                let pid = free.pop();
                if (pid === undefined) {
                    let old = null;
                    pool.forEach((x, k) => { if (x.t < frameNo && (!old || x.t < pool.get(old).t)) old = k; });
                    if (!old) return null;                 // all drawn in this frame already
                    pid = pool.get(old).pid; pool.delete(old);
                }
                pool.set(id, e = { pid, th: null, t: 0 });
            }
            if (e.th !== th) { e.th = th; setImage(e.pid, th.w, th.h, th.buf); }
            e.t = frameNo;
            return e.pid;
        }

        // a play triangle pointing right, centred on cx, cy, s px tall
        const tri = (cv, cx, cy, s, c) => cv.quad([[cx - s * 0.38, cy - s / 2], [cx + s * 0.5, cy], [cx - s * 0.38, cy + s / 2], [cx - s * 0.38, cy - s / 2]], c);
        // Try again: a circle arrow (cv.arc's ring, its head at the top)
        const retryGlyph = (cv, cx, cy, r, c) => { cv.arc(cx, cy, r - 5, r, 40, 340, c); cv.quad([[cx - 4, cy - r - 9], [cx + 10, cy - r + 2], [cx - 4, cy - r + 12], [cx - 4, cy - r - 9]], c); };
        // iYT's mark: a cyan screen outline with the pink play mark in it
        const logo = (cv, cx, cy, w) => Brand.draw(cv, cx, cy, w);

        /* the left rail: Search, Home, Subscriptions, Watch later */
        const RAIL = [
            ['search', 'Search', (cv, x, y, c) => { cv.arc(x - 4, y - 4, 9, 12.5, 0, 360, c); cv.line(x + 4.5, y + 4.5, x + 14, y + 14, 4.5, c); }],
            ['home', 'Home', (cv, x, y, c, bg) => {
                cv.quad([[x, y - 18], [x + 19, y - 1], [x - 19, y - 1], [x, y - 18]], c);
                cv.fillRect(x - 13, y - 3, 26, 19, c); cv.fillRect(x - 4, y + 6, 8, 10, bg);
            }],
            ['subs', 'Subscriptions', (cv, x, y, c, bg) => {
                cv.roundRect(x - 11, y - 18, 22, 3, 1.5, c); cv.roundRect(x - 15, y - 12, 30, 3, 1.5, c);
                cv.roundRect(x - 18, y - 6, 36, 24, 5, c); tri(cv, x + 1, y + 6, 12, bg);
            }],
            ['wl', 'Watch later', (cv, x, y, c) => { cv.arc(x, y, 14, 17.5, 0, 360, c); cv.line(x, y + 1, x, y - 9, 3.5, c); cv.line(x, y, x + 7, y + 5, 3.5, c); }],
        ];
        // while something plays: back to the player (the bar's Now playing, where the kit runs the screen)
        const PLAYING = ['player', 'Playing', (cv, x, y, c) => { [10, 20, 14].forEach((h, k) => cv.roundRect(x - 15 + k * 11, y + 8 - h, 8, h + 8, 2, c)); }];
        function drawRail(cv) {
            Brand.draw(cv, 54, TOP + 33, 60);
            cv.text('iYT', 92, TOP + 44, 34, C.text, LITB);
            const items = [['home','Home',150],['subs','Subscriptions',210],['wl','Watch later',180],['menu','Menu',120]];
            let x = 220;
            items.forEach(([name,label,width]) => {
                const selected = mode === name || (name === 'subs' && mode === 'channel');
                cv.roundRect(x, TOP + 8, width, 44, 9, selected ? C.red : C.bg);
                cv.text(label, x + width/2, TOP + 37, 23, selected ? '#ffffff' : C.dim, {literal:true,align:'center',font:'bold'});
                if (cv.own) cv.target(x,TOP+8,width,44,() => name === 'menu' ? ui.open('MAIN') : show(name),'nav:'+name,9,undefined,1);
                x += width + 10;
            });
        }

        const KEYS = (cv, cx, cy, c) => {                 // a keyboard
            cv.strokeRoundRect(cx - 46, cy - 30, 92, 60, 10, 4, c);
            for (let k = 0; k < 5; k++) { cv.roundRect(cx - 34 + k * 15, cy - 18, 9, 9, 2, c); cv.roundRect(cx - 34 + k * 15, cy - 3, 9, 9, 2, c); }
            cv.roundRect(cx - 24, cy + 12, 48, 8, 3, c);
        };
        const BLOCK = (cv, cx, cy, c) => { cv.arc(cx, cy, 30, 36, 0, 360, c); cv.line(cx - 22, cy + 22, cx + 22, cy - 22, 6, c); };   // hide
        const SHOW = (cv, cx, cy, c) => { cv.arc(cx, cy, 30, 36, 0, 360, c); cv.polyline([[cx - 15, cy], [cx - 4, cy + 12], [cx + 16, cy - 12]], 6, c); };
        const ALL = (cv, cx, cy, c) => { [-20, 0, 20].forEach((d) => cv.roundRect(cx - 34, cy + d - 4, 68, 8, 4, c)); };
        // the channels, filtered by chanQ (the keyboard: one letter = names starting with it, else names holding it)
        let chanQ = '';
        function findChannel() {
            return openSearch('channel');
        }
        let chanFrom = 'subs';
        function openChannel(c) { if (mode !== 'channel') chanFrom = mode; model.openChannel(c.id, c.title); show('channel'); vs('channel').sy = 0; vs('channel').off = {}; }
        function chanSections() {
            const ch = model.chans;
            if (!ch || (!ch.items.length && ch.loading)) return [{ title: 'Channels', sub: 'Loading...', items: [], chan: true }];
            if (!ch.items.length) return ch.error ? [{ title: 'Channels', sub: ch.error, items: [], chan: true }] : [];
            const find = { id: '::find', title: chanQ ? 'Search again' : 'Search channels', sub: 'A letter, or a word', act: findChannel, glyph: KEYS };
            if (!chanQ) return [{ title: 'Channels', sub: ch.items.length + ' subscriptions, A-Z', items: [find].concat(ch.items), chan: true }];
            const hits = model.findChannels(chanQ);
            const all = { id: '::all', title: 'All channels', sub: ch.items.length + ' subscriptions', act: () => { chanQ = ''; vs('subs').off = {}; dirty = true; }, glyph: ALL };
            return [{ title: (chanQ.length === 1 ? 'Channels starting with “' : 'Channels matching “') + chanQ + '”',
                sub: hits.length ? hits.length + (hits.length === 1 ? ' channel' : ' channels') : 'none', items: [find, all].concat(hits), chan: true, grid: true }];
        }
        function drawChannel(cv) {
            const c = model.chan;
            if (!model.connected) return say(cv, OFF, OFF2);
            if (!c) return say(cv, 'Pick a channel in Subscriptions');
            if (!c.items.length) return say(cv, c.loading ? 'Loading ' + (c.title || 'the channel') + '...' : c.error === 'feed offline' ? 'The video service is not reachable - check the car\'s internet connection' : c.error || 'No videos on this channel', c.title || null);
            const hid = hidden.indexOf(c.title) >= 0;
            const tog = { id: '::hide', title: hid ? 'Show this channel' : 'Hide this channel', sub: hid ? 'Hidden from Home, Subscriptions, Search' : 'From Home, Subscriptions and Search',
                act: () => toggleHidden(c.title), glyph: hid ? SHOW : BLOCK };
            drawPage(cv, (c.shelves && c.shelves.length ? c.shelves : [{ title: 'Videos', items: c.items, grid: true }])
                .map((s, i) => (i === 0 ? Object.assign({}, s, { title: c.title + (s.title ? ' · ' + s.title : ''), items: [tog].concat(s.items) }) : s)));
        }

        // Shared vertical layout for feeds, results and channel pages.
        const view = {};                                  // mode -> { sy, off: { row: first tile shown } }
        const vs = (m) => view[m] || (view[m] = { sy: 0, max: 0, off: {} });
        let laid = { mode: null, rows: [], viewH: 0, where: {} }, focusKey = null, dwell = null;
        function layout(sections, rowH) {
            const rows = [];
            let y = 6;
            sections.forEach((sc) => sc.items.forEach((item,i) => {
                const title = i === 0 ? sc.title : null;
                const head = title ? 34 : 0;
                rows.push({title,items:[item],y,h:head+rowH+8,head,chan:!!sc.chan,hs:false});
                y += head + rowH + 8;
            }));
            return {rows,h:y};
        }
        function drawPage(cv, sections) {
            const top = TOP + 80, bottom = H + (cv.own ? cv.extra : 0), viewH = bottom - top;
            const rowH = Math.max(112,Math.min(142,Math.floor((viewH-64)/3)));
            const st = vs(mode), L = layout(sections,rowH), where = {}, letter = mode[0];
            st.max = Math.max(0,L.h-viewH); st.sy = Math.max(0,Math.min(st.max,st.sy));
            const allVideos = sections.reduce((items,sc) => sc.chan ? items : items.concat(sc.items.filter((item) => !item.act)),[]);
            cv.clip(20,top,W-40,viewH);
            L.rows.forEach((row,ri) => {
                const y = top + row.y - st.sy;
                if (y + row.h < top-rowH || y > bottom+rowH) return;
                const item = row.items[0], key = letter+':'+ri+':'+item.id, cy = y+row.head;
                const visible = cy+rowH>top && cy<bottom, x=26, width=W-52;
                if (row.title && y+34>top && y<bottom) cv.text(fit(cv,row.title,24,width,LITB),x+4,y+25,24,C.dim,LITB);
                if (visible) {
                    cv.roundRect(x,cy,width,rowH,12,key===focusKey?'#21364b':C.card);
                    if (key===focusKey) cv.strokeRoundRect(x,cy,width,rowH,12,3,C.red);
                    const th=rowH-16, tw=Math.round(th*16/9), tx=x+tw+30;
                    if (row.chan || item.act) {
                        const cx=x+tw/2+8, my=cy+rowH/2;
                        cv.circle(cx,my,Math.min(th/2-4,40),C.ph);
                        if (item.glyph) item.glyph(cv,cx,my,C.text);
                        else cv.text((String(item.title||item.id)[0]||'?').toUpperCase(),cx,my+13,36,C.text,{literal:true,font:'bold',align:'center'});
                    } else {
                        const thumb=model.thumbs[item.id];
                        if (!thumb) model.wantThumb(item.id);
                        const pid=thumb&&cv.place?slot(item.id,thumb):null;
                        if (pid) cv.picture(pid,x+8,cy+8,tw,th,8);
                        else {cv.roundRect(x+8,cy+8,tw,th,8,C.ph);tri(cv,x+8+tw/2,cy+rowH/2,24,C.dim);}
                        if (item.duration_s>0) {
                            const text=clock(item.duration_s*1000), bw=cv.textWidth(text,18,LITB)+14;
                            cv.roundRect(x+tw-bw+2,cy+rowH-35,bw,24,5,'#000000d9');
                            cv.text(text,x+tw-5,cy+rowH-17,18,'#ffffff',{literal:true,font:'bold',align:'right'});
                        }
                    }
                    cv.text(fit(cv,item.title||item.id,30,width-(tx-x)-70,LITB),tx,cy+rowH*0.43,30,C.text,LITB);
                    const detail=item.sub||[item.channel,(item.meta||[]).join(' · ')].filter(Boolean).join(' · ')||item.handle||'';
                    cv.text(fit(cv,detail,22,width-(tx-x)-70,LIT),tx,cy+rowH*0.73,22,C.dim,LIT);
                    cv.polyline([[x+width-36,cy+rowH/2-8],[x+width-28,cy+rowH/2],[x+width-36,cy+rowH/2+8]],3,C.dim);
                    const progress=model.pos[item.id];
                    if (progress&&progress.total) cv.fillRect(tx,cy+rowH-9,Math.round((width-(tx-x)-64)*Math.min(1,progress.ms/progress.total)),3,C.red);
                }
                if (cv.own) {
                    const action=item.act?()=>item.act():row.chan?()=>openChannel(item):()=>play(item.id,item,allVideos);
                    const hit=visible?{x,y:Math.max(top,cy),w:width,h:Math.max(0,Math.min(bottom,cy+rowH)-Math.max(top,cy))}:false;
                    cv.target(x,cy,width,rowH,action,key,12,undefined,0,hit);
                    where[key]={ri,i:0};
                }
            });
            cv.noclip();
            laid={mode,rows:L.rows,viewH,where};
            if (st.max>0) {
                const thumbH=Math.max(28,viewH*viewH/L.h), thumbY=top+(viewH-thumbH)*st.sy/st.max;
                cv.roundRect(W-12,top,4,viewH,2,C.ph);
                cv.roundRect(W-12,thumbY,4,thumbH,2,C.red);
                if (cv.own) cv.scroll={y:top,bar:{x:W-12,y:thumbY,w:4,h:thumbH}};
            }
        }
        // the controller on a tile: its shelf turned and the page scrolled so that it shows whole
        if (ctx.onPageFocus) ctx.onPageFocus((key) => {
            if (key !== focusKey) dirty = true;
            focusKey = key;
            // resting ~1 s on a video: the daemon looks its streams up now, so a press plays ~2.5 s sooner
            clearTimeout(dwell);
            const vid = /^[a-z]+:\d+:([A-Za-z0-9_-]{11})$/.exec(key || '');
            if (vid) dwell = setTimeout(() => { if (focusKey === key) model.prefetch(vid[1]); }, 1000);
            if (key && key.indexOf('ov:') === 0) { wake(); return; }      // the controller in the player: its overlay
            const w = key && laid.mode === mode && laid.where[key];
            if (!w) return;
            const st = vs(mode), row = laid.rows[w.ri];
            if (row.hs) {

            }
            const top = row.y - 8, bot = row.y + row.h;
            if (top < st.sy) st.sy = Math.max(0, top); else if (bot > st.sy + laid.viewH) st.sy = Math.min(st.max, bot - laid.viewH);
            dirty = true;
        });
        if (ctx.onScroll) ctx.onScroll((dy) => {
            if (!browsing()) return false;
            const st = vs(mode), y = Math.max(0, Math.min(st.max, st.sy + dy)), moved = y !== st.sy;
            st.sy = y;
            if (moved) dirty = true;
            return moved;
        });

        // a message in the middle of the page (iYT's mark over it), a grey line under it
        const MID = (RAIL_W + W) / 2;
        function say(cv, msg, sub) {
            if (browsing()) logo(cv, MID, 200, 76);
            cv.text(fit(cv, msg, 34, 1360, LIT), browsing() ? MID : W / 2, 290, 34, '#ffffff', { literal: true, align: 'center' });
            if (sub) cv.text(fit(cv, sub, 24, 1360, LIT), browsing() ? MID : W / 2, 336, 24, C.dim, { literal: true, align: 'center' });
        }
        const OFF = 'The iYT service (iyt-daemon) is not running';
        const OFF2 = 'Install the iYT service (iyt-daemon) from the MGU Store';
        function drawResults(cv) {
            if (!model.connected) return say(cv, OFF, OFF2);
            if (model.searching) return say(cv, 'Searching "' + model.q + '"...');
            if (model.searchError) return say(cv, 'Search: ' + model.searchError, 'Try again from Search');
            if (!model.results.length) return say(cv, model.q ? 'Nothing found for "' + model.q + '"' : 'Search (bar button) to find videos', model.q ? 'Try other words' : null);
            drawPage(cv, [{ title: 'Results for “' + model.q + '”', items: shown(model.results), grid: true }]);
        }
        function drawFeed(cv, which) {
            const f = model.feeds[which], a = model.auth.state;
            if (!model.connected) return say(cv, OFF, OFF2);
            if (a === 'unsupported') return say(cv, 'Signing in needs a newer iyt-daemon tool on the car');
            if (a !== 'signed_in') return drawSignIn(cv);
            const chans = which === 'subs' && model.chans && model.chans.items.length;   // the channels show without the videos
            if ((!f || !f.items.length) && !chans) {
                return say(cv, !f || f.loading ? 'Loading ' + NAMES[which] + '...' : f.error === 'feed offline' ? 'The video service is not reachable - check the car\'s internet connection'
                    : f.error ? NAMES[which] + ': ' + f.error : which === 'wl' ? 'Nothing in Watch later' : 'No videos here yet', which === 'wl' && f && !f.loading && !f.error ? 'Videos you save for later show here' : null);
            }
            let secs;
            if (which === 'home') {
                const wl = model.feeds.wl;
                secs = (model.resume.length ? [{ title: 'Continue watching', items: model.resume }] : [])
                    .concat(f.shelves || [{ title: 'Recommended', items: f.items, grid: true }])
                    .concat(wl && wl.items.length ? [{ title: 'Watch later', items: wl.items.slice(0, SHELF_MAX) }] : []);
            } else secs = !f ? [] : f.shelves && which !== 'wl' ? f.shelves : [{ title: NAMES[which], sub: f.items.length + ' videos', items: f.items, grid: true }];
            if (which === 'subs') secs = chanSections().concat(chanQ || !f || !f.items.length ? [] : secs);
            drawPage(cv, secs.map((sc) => (sc.chan ? sc : Object.assign({}, sc, { items: shown(sc.items) }))).filter((sc) => sc.chan || sc.items.length));
        }
        // not signed in: a QR code for the sign-in page, the code to enter there in big letters, on a card
        function drawSignIn(cv) {
            const a = model.auth;
            // a code expired or refused, or signed out: a new one only when asked (a tap, or Sign in in the menu)
            if (a.state === 'error' || a.state === 'signed_out') {
                say(cv, a.state === 'error' ? 'Sign-in is not available (' + (a.msg || 'error') + ') - tap to try again'
                    : cv.own ? 'Tap here to get a sign-in code' : 'Sign in (menu) to get a sign-in code',
                'Your Home, Subscriptions and Watch later, on the car');
                if (cv.own) cv.target(MID - 520, 160, 1040, 200, () => model.authStart(true), 'signin', 16);
                return;
            }
            if (a.state !== 'code' || !a.code) return say(cv, 'Getting a sign-in code...');
            let url = /^https:\/\//.test(a.url || '') ? a.url : SIGNIN_URL, q;
            try { q = QR.encode(url); } catch (e) { url = SIGNIN_URL; q = QR.encode(url); }   // longer than a version 4 code holds
            const code = { literal: true, font: 'bold', spacing: 6 }, cwid = cv.textWidth(a.code, 54, code), hint = 'Scan the code, or go to ' + url.replace(/^https:\/\/(www\.)?/, '');
            const side = (q.length + 8) * 8, textW = Math.max(cwid + 56, cv.textWidth(hint, 26, LIT), 88 + cv.textWidth('Sign in', 44, LITB), 560);
            const cw = Math.min(1400, 44 + side + 80 + textW + 64), ch = 444, cx = Math.round(MID - cw / 2), cy = TOP + Math.max(14, Math.round((H + (cv.own ? cv.extra : 0) - TOP - ch) / 2)), dy = cy - 58;
            cv.roundRect(cx, cy, cw, ch, 24, C.card);
            const qx = cx + 44, qy = cy + Math.round((ch - side) / 2);
            cv.roundRect(qx - 6, qy - 6, side + 12, side + 12, 18, '#ffffff');
            QR.draw(cv, url, qx, qy, 8);
            const tx = qx + side + 80;
            logo(cv, tx + 34, 128 + dy, 68);
            cv.text('Sign in', tx + 88, 144 + dy, 44, '#ffffff', LITB);
            cv.text('Enter this code on your phone', tx, 214 + dy, 30, C.dim, LIT);
            cv.roundRect(tx, 238 + dy, cwid + 56, 96, 16, C.bg);
            cv.text(a.code, tx + 28, 308 + dy, 54, '#ffffff', code);
            cv.text(hint, tx, 392 + dy, 26, C.dim, LIT);
            cv.text('The account stays on the car; this app never sees a password', tx, 440 + dy, 20, '#717171', LIT);
        }
        function drawPlayer(cv) {
            cv.fillRect(0, TOP, W, H - TOP, '#000000');
            cv.fillRect(BOX.x, BOX.y, BOX.w, BOX.h, '#000000');
            if (videoShown) cv.video(VID, BOX.x, BOX.y, BOX.w, BOX.h, 0);
            const cx = BOX.x + BOX.w / 2, cy = BOX.y + BOX.h / 2 - 10, bot = BOX.y + BOX.h;
            // the title and channel over a scrim at the top
            if (model.title) {
                cv.gradientRect(BOX.x, BOX.y, BOX.w, 130, [[0, '#000000d0'], [1, '#00000000']]);
                const it = model.item(model.id);
                cv.text(fit(cv, model.title, 30, BOX.w - 60, LITB), BOX.x + 30, BOX.y + 48, 30, '#ffffff', LITB);
                if (it && it.channel) cv.text(fit(cv, it.channel, 22, BOX.w - 60, LIT), BOX.x + 30, BOX.y + 82, 22, '#cccccc', LIT);
            }
            let mid = null;
            if (!model.connected) mid = 'The iYT service (iyt-daemon) is not running';
            else if (model.state === 'preparing') {
                const p = Math.max(0, Math.min(100, model.pct || 0));
                cv.circle(cx, cy - 20, 54, '#00000099');
                cv.arc(cx, cy - 20, 44, 52, 0, 360, '#ffffff26');
                if (p > 0) cv.arc(cx, cy - 20, 44, 52, 0, p * 3.6, C.red, { round: true });
                cv.text(Math.round(p) + '%', cx, cy - 10, 30, '#ffffff', { literal: true, font: 'bold', align: 'center' });
                cv.text(prepText(), cx, cy + 82, 26, '#dddddd', { literal: true, align: 'center' });
            } else if (model.state === 'error') mid = 'Error: ' + (model.error || 'playback stopped');
            else if (!model.active()) mid = model.state === 'ended' ? 'Finished' : 'Pick a video on Home or Search';
            else if (noVideo()) mid = 'Video stops while driving - the sound plays on';
            else if (!cv.place || !gpu()) mid = 'The picture needs the GPU renderer (mgu-render) - the sound plays';
            else if (!videoShown) mid = 'Starting the picture...';
            if (model.state === 'paused' && !mid) { cv.circle(cx, cy, 60, '#000000a0'); cv.arc(cx, cy, 57, 60, 0, 360, '#ffffff50'); tri(cv, cx + 5, cy, 46, '#ffffff'); }
            if (mid) {
                if (model.state === 'paused') { cv.circle(cx, cy - 40, 46, '#000000a0'); tri(cv, cx + 4, cy - 40, 36, '#ffffff'); }
                cv.text(fit(cv, mid, 34, 1500, LIT), W / 2, BOX.y + BOX.h / 2 + (model.state === 'paused' ? 50 : 12), 34, '#ffffff', { literal: true, align: 'center' });
            }
            // the progress bar at the bottom: the track, the part played, the scrubber; the times under it
            if (model.total > 0 && model.active() && model.state !== 'preparing') {
                cv.gradientRect(BOX.x, bot - 120, BOX.w, 120, [[0, '#00000000'], [1, '#000000d8']]);
                const tx = BOX.x + 30, tw = BOX.w - 60, ty = bot - 62, k = Math.min(1, model.elapsed / model.total), fx = tx + Math.round(tw * k);
                cv.roundRect(tx, ty, tw, 6, 3, '#ffffff55');
                cv.roundRect(tx, ty, fx - tx, 6, 3, C.red);
                cv.circle(fx, ty + 3, 9, C.red);
                cv.text(clock(model.elapsed), tx, bot - 20, 24, '#ffffff', LITB);
                cv.text(clock(model.total), tx + tw, bot - 20, 24, '#dddddd', { literal: true, font: 'bold', align: 'right' });
            }
        }
        /*
         * The player where the kit runs the screen: the video over the whole surface (no header, no bar), the
         * overlay over it, drawn in screen px / scale (sharp text) at the screen's origin. Its targets go back into
         * the page's px (dx, dy). Hidden, the same keys cover the whole screen and only show it again (the
         * controller stays on its key, so a turn or a press wakes it; a tap anywhere too).
         */
        const OVK = ['ov:back', 'ov:qr', 'ov:rw', 'ov:play', 'ov:ff', 'ov:q', 'ov:zoom', 'ov:bar'];
        // podcast mode (driving): artwork, title, chapter, the bar with chapter ticks and skipped segments, controls
        // a glove can hit (-10 s, play/pause, +10 s, next in the row), the next video, a skipped-sponsor notice
        function drawPodcast(cv, SW, SH, LX, tg, run, live) {
            cv.fillRect(0, 0, SW, SH, C.bg);
            const x0 = LX + 46, top = 40, ch = model.channel || (model.item(model.id) || {}).channel;
            cv.text('iYT', x0, top + 30, 34, '#ffffff', LITB);
            const chip = 'Podcast mode · driving', cw = cv.textWidth(chip, 22, LIT) + 40;
            cv.roundRect(x0 + 170, top, cw, 40, 20, C.ph);
            cv.text(chip, x0 + 170 + cw / 2, top + 28, 22, C.dim, { literal: true, align: 'center' });
            cv.text('Video returns when parked', SW - 60, top + 28, 22, '#717171', { literal: true, align: 'right' });
            // laid out from the bottom: the notice / up-next row, the controls, the bar; the artwork takes what is left
            const cy = SH - 178, by = cy - 128, ay = top + 72, ah = Math.max(120, by - 56 - ay), aw = Math.round(ah * 16 / 9), ax = x0;
            const th = model.thumbs[model.id];
            if (!th) model.wantThumb(model.id);
            const pid = th && cv.place ? slot(model.id, th) : null;
            if (pid) cv.picture(pid, ax, ay, aw, ah, 24); else { cv.roundRect(ax, ay, aw, ah, 24, C.ph); tri(cv, ax + aw / 2 + 4, ay + ah / 2, 50, '#ffffff38'); }
            // title block
            const tx = ax + aw + 70, tw = SW - tx - 60;
            if (ch) cv.text(fit(cv, ch, 28, tw, LIT), tx, ay + 30, 28, C.dim, LIT);
            const words = String(model.title || model.id || '').split(/\s+/).filter(Boolean);
            let l1 = '', i = 0;
            for (; i < words.length; i++) { const t = l1 ? l1 + ' ' + words[i] : words[i]; if (l1 && cv.textWidth(t, 44, LITB) > tw) break; l1 = t; }
            [fit(cv, l1, 44, tw, LITB), fit(cv, words.slice(i).join(' '), 44, tw, LITB)].filter(Boolean).forEach((l, k) => cv.text(l, tx, ay + 84 + k * 52, 44, '#ffffff', LITB));
            const chap = model.chapter();
            if (chap) cv.text(fit(cv, chap, 28, tw, LIT), tx, ay + ah - 6, 28, '#3ea6ff', LIT);
            // the bar
            const bw = SW - x0 - 60, tot = model.total, ex = model.extras && model.extras.id === model.id ? model.extras : null;
            const at = (ms) => x0 + Math.round(bw * Math.min(1, tot ? ms / tot : 0));
            cv.roundRect(x0, by, bw, 10, 5, '#3f3f3f');
            if (tot > 0) {
                const el = shownAt(), bf = focusKey === 'ov:bar';
                cv.roundRect(x0, by, Math.max(10, at(el) - x0), 10, 5, C.red);
                if (ex) sbSegs(ex).forEach((g) => cv.fillRect(at(g[0]), by, Math.max(4, at(g[1]) - at(g[0])), 10, sbColor(g)));
                if (ex) ex.chapters.forEach((k) => { if (k[0] > 0) cv.fillRect(at(k[0]) - 2, by, 4, 10, C.bg); });
                if (bf) cv.circle(at(el), by + 5, 24, '#3ea6ff');
                cv.circle(at(el), by + 5, bf ? 18 : 14, C.red);
                tg(x0 - 10, by - 36, bw + 20, 80, run(() => model.toggle()), 'ov:bar', 0, turnSeek);
                cv.text(clock(el), x0, by + 50, 26, C.dim, LIT);
                cv.text('-' + clock(tot - el), x0 + bw, by + 50, 26, C.dim, { literal: true, align: 'right' });
            } else if (model.state === 'preparing') cv.text(prepText(), x0, by + 50, 26, C.dim, LIT);
            // controls
            const mid = x0 + bw / 2 + (queue.length ? 0 : 100);   // with Next: four buttons; without: three, centred
            const big = (key, x, r, light, fn, glyph) => {
                const f = focusKey === key;
                cv.circle(x, cy, r, f ? '#3ea6ff' : light ? '#ffffff' : C.ph);
                glyph(light && !f ? C.bg : '#ffffff');
                tg(x - r - 10, cy - r - 10, 2 * r + 20, 2 * r + 20, run(fn), key, r + 10);
            };
            const num = (t, x) => (c) => cv.text(t, x, cy + 14, 38, c, { literal: true, font: 'bold', align: 'center' });
            if (live) {
                big('ov:rw', mid - 300, 58, false, () => model.skip(-10000), num('-10', mid - 300));
                big('ov:play', mid - 100, 72, true, () => model.toggle(), (c) => {
                    if (model.state === 'paused') tri(cv, mid - 92, cy, 60, c);
                    else { cv.roundRect(mid - 124, cy - 32, 16, 64, 4, c); cv.roundRect(mid - 92, cy - 32, 16, 64, 4, c); }
                });
                big('ov:ff', mid + 100, 58, false, () => model.skip(10000), num('+10', mid + 100));
            }
            else if (model.state === 'error' && model.id) big('ov:play', mid - 100, 72, true, again, (c) => retryGlyph(cv, mid - 100, cy, 30, c));
            if (queue.length) {
                const nx = mid + 300;
                big('ov:next', nx, 58, false, () => { const r = queue.shift(); play(r.id, r); }, (c) => {
                    cv.quad([[nx - 22, cy - 26], [nx - 22, cy + 26], [nx + 12, cy], [nx - 22, cy - 26]], c); cv.fillRect(nx + 14, cy - 26, 9, 52, c);
                });
                const up = 'Up next  ·  ' + String(queue[0].title || queue[0].id), uw = Math.min(700, cv.textWidth(up, 26, LIT) + 50);
                cv.roundRect(SW - 60 - uw, SH - 96, uw, 64, 16, '#1c1c1c');
                cv.text(fit(cv, up, 26, uw - 50, LIT), SW - 60 - uw + 25, SH - 54, 26, '#dddddd', LIT);
            }
            const ask = askSeg();
            if (ask) {
                const tt = 'Skip ' + sbName(ask[2]), w2 = cv.textWidth(tt, 30, LITB) + 80, f = focusKey === 'ov:sbskip';
                cv.roundRect(x0, SH - 100, w2, 72, 36, f ? '#3ea6ff' : '#ffffff');
                cv.text(tt, x0 + 40, SH - 52, 30, f ? '#ffffff' : C.bg, LITB);
                tg(x0, SH - 100, w2, 72, run(sbJump(ask)), 'ov:sbskip', 36);
            } else if (model.toast && Date.now() < model.toast.until) {
                const tt = model.toast.text, w2 = cv.textWidth(tt, 26, LIT) + 60, wn = model.toast.warn;
                cv.roundRect(x0, SH - 96, w2, 64, 32, wn ? '#4a3a10' : '#1f3d1f');
                cv.text(tt, x0 + 30, SH - 54, 26, wn ? '#ffd27a' : '#7ee07e', LIT);
            }
            if (model.state === 'error') cv.text(fit(cv, 'Error: ' + (model.error || 'playback stopped'), 28, bw, LIT), x0, SH - 54, 28, '#ff6b6b', LIT);
        }
        function drawFull(cv) {
            const pl = cv.place, s = pl.scale, SW = pl.w / s, SH = pl.h / s, dx = pl.ox / s, dy = pl.oy / s;
            cv.chrome = null;              // no header or bar composed over it (display.js present)
            // read: the page stays placed as the browsing pages (reaching down), so oy, and the targets with it, hold
            void cv.extra;
            const tg = (x, y, w, h, run, key, r, turn) => cv.target(x - dx, y - dy, w, h, run, key, r, turn);
            cv.xf(1, 0, 0).fillRect(0, 0, pl.w, pl.h, '#000000');
            const pod = model.active() && noVideo();   // driving: podcast mode (no picture, big controls, always shown)
            if (videoShown && !pod) cv.video(VID, 0, 0, pl.w, pl.h, 0);
            if (!overlay() && !pod) { cv.xf(); OVK.forEach((k) => tg(0, 0, SW, SH, wake, k, 0, k === 'ov:bar' ? turnSeek : undefined)); return; }
            cv.xf(s, 0, 0);
            const LX = HMI.left / s, act = model.active(), live = model.state === 'playing' || model.state === 'paused';
            const cx = SW / 2, cy = SH / 2 - 6, run = (fn) => () => { fn(); wake(); };
            if (pod) { drawPodcast(cv, SW, SH, LX, tg, run, live); hmiIcons(cv); return; }
            // a round control: dark, white when the controller is on it (its glyph dark then)
            const ctl = (key, x, y, r, fn, glyph) => {
                const f = focusKey === key;
                cv.circle(x, y, r, f ? '#ffffff' : '#00000099');
                glyph(f ? '#0f0f0f' : '#ffffff');
                tg(x - r - 6, y - r - 6, 2 * r + 12, 2 * r + 12, run(fn), key, r + 6);
            };
            // top: back to the list, the title and channel over a scrim
            cv.gradientRect(0, 0, SW, 160, [[0, '#000000d8'], [1, '#00000000']]);
            const bx = LX + 44, by = 52;
            ctl('ov:back', bx, by, 30, () => backToBrowse(), (c) => cv.polyline([[bx + 5, by - 12], [bx - 7, by], [bx + 5, by + 12]], 5, c));
            const ch = model.channel || (model.item(model.id) || {}).channel;
            if (model.title) cv.text(fit(cv, model.title, 30, SW - LX - 160, LITB), LX + 96, by - 4, 30, '#ffffff', LITB);
            if (ch) cv.text(fit(cv, ch, 22, SW - LX - 300, LIT), LX + 96, by + 30, 22, '#cccccc', LIT);
            // top right, On phone: a QR code of the video's public link at this second (nothing is kept on the car)
            if (model.id) {
                const px = SW - 150;
                ctl('ov:qr', px, by, 30, () => { qrUntil = qrUntil > Date.now() ? 0 : Date.now() + 30000; }, (c) => {
                    cv.strokeRoundRect(px - 10, by - 17, 20, 34, 4, 3, c); cv.fillRect(px - 4, by + 10, 8, 3, c);
                });
                cv.text('On phone', px - 42, by + 9, 24, '#ffffff', Object.assign({}, LIT, { align: 'right' }));
            }
            if (model.id && qrUntil > Date.now()) {
                const url = 'https://youtu.be/' + model.id + (model.elapsed > 5000 ? '?t=' + Math.floor(model.elapsed / 1000) : ''), mod = 8;
                const n = QR.encode(url).length, side = (n + 8) * mod, cw = side + 520, chh = side + 60, qx0 = cx - cw / 2, qy0 = cy - chh / 2;
                cv.roundRect(qx0, qy0, cw, chh, 24, '#212121f2');
                cv.roundRect(qx0 + 30 - 6, qy0 + 30 - 6, side + 12, side + 12, 18, '#ffffff');
                QR.draw(cv, url, qx0 + 30, qy0 + 30, mod);
                cv.text('Continue on your phone', qx0 + side + 80, qy0 + chh / 2 - 20, 34, '#ffffff', LITB);
                cv.text('Scan with the camera to go on from ' + clock(model.elapsed), qx0 + side + 80, qy0 + chh / 2 + 24, 22, '#cccccc', LIT);
                tg(qx0, qy0, cw, chh, () => { qrUntil = 0; wake(); }, 'ov:qrcard', 24);
                cv.xf();
                return;
            }
            // middle: -10 s, play / pause, +10 s; preparing: the ring with the percentage
            let mid = null;
            if (!model.connected) mid = OFF;
            else if (model.state === 'error') mid = 'Error: ' + (model.error || 'playback stopped');
            const up = upNext;
            if (up) {
                mid = 'Up next in ' + Math.max(1, Math.ceil((nextAt - Date.now()) / 1000)) + ' s: ' + String(up.title || up.id);
                ctl('ov:play', cx, cy, 58, () => { nextAt = 1; }, (c) => tri(cv, cx + 5, cy, 46, c));
            } else if (!act && model.state !== 'error') mid = model.state === 'ended' ? 'Finished' : 'Pick a video on Home or Search';
            else if (noVideo()) mid = 'Video stops while driving - the sound plays on';
            else if (!gpu()) mid = 'The picture needs the GPU renderer (mgu-render) - the sound plays';
            else if (live && !videoShown) mid = 'Starting the picture...';
            if (model.state === 'preparing') {
                const p = Math.max(0, Math.min(100, model.pct || 0));
                cv.circle(cx, cy, 56, '#00000099');
                cv.arc(cx, cy, 44, 52, 0, 360, '#ffffff26');
                if (p > 0) cv.arc(cx, cy, 44, 52, 0, p * 3.6, C.red, { round: true });
                cv.text(Math.round(p) + '%', cx, cy + 10, 30, '#ffffff', { literal: true, font: 'bold', align: 'center' });
                cv.text(prepText(), cx, cy + 100, 26, '#dddddd', { literal: true, align: 'center' });
            } else if (live) {
                const skip = (key, x, dir, ms) => ctl(key, x, cy, 42, () => model.skip(ms), (c) => {
                    cv.arc(x, cy, 19, 23.5, dir < 0 ? 0 : 60, dir < 0 ? 300 : 360, c);
                    cv.quad([[x - 1 * dir, cy - 29], [x + 9 * dir, cy - 21], [x - 1 * dir, cy - 13], [x - 1 * dir, cy - 29]], c);
                    cv.text('10', x, cy + 7, 18, c, { literal: true, font: 'bold', align: 'center' });
                });
                skip('ov:rw', cx - 210, -1, -10000);
                ctl('ov:play', cx, cy, 58, () => model.toggle(), (c) => {
                    if (model.state === 'paused') tri(cv, cx + 5, cy, 46, c);
                    else { cv.roundRect(cx - 17, cy - 22, 12, 44, 3, c); cv.roundRect(cx + 5, cy - 22, 12, 44, 3, c); }
                });
                skip('ov:ff', cx + 210, 1, 10000);
                // right: Video quality (a press takes the next one; the video starts again there) and zoom (fill crops)
                const qv = String(settings.get('quality') || 'auto'), fl = settings.get('fill') !== false, qx = SW - 330, zx = SW - 150;
                ctl('ov:q', qx, cy, 42, () => { const q = QUALITIES[(QUALITIES.indexOf(qv) + 1) % QUALITIES.length]; settings.set('quality', q); model.quality(q); },
                    (c) => cv.text(qv === 'auto' ? 'Auto' : qv + 'p', qx, cy + 8, 22, c, { literal: true, font: 'bold', align: 'center' }));
                cv.text('Quality', qx, cy + 76, 22, '#dddddd', { literal: true, align: 'center' });
                ctl('ov:zoom', zx, cy, 42, () => { settings.set('fill', !fl); model.fill(!fl); }, (c) => {
                    cv.strokeRoundRect(zx - 22, cy - 15, 44, 30, 4, 3, c);
                    if (fl) cv.fillRect(zx - 22, cy - 15, 44, 30, c); else cv.fillRect(zx - 12, cy - 15, 24, 30, c);
                });
                cv.text(fl ? 'Unzoom' : 'Zoom', zx, cy + 76, 22, '#dddddd', { literal: true, align: 'center' });
            } else if (model.state === 'error' && model.id && model.connected) {
                ctl('ov:play', cx, cy, 58, again, (c) => retryGlyph(cv, cx, cy, 26, c));
                cv.text('Try again', cx, cy + 100, 26, '#dddddd', { literal: true, align: 'center' });
            }
            if (mid) cv.text(fit(cv, mid, 30, SW - 2 * LX, LIT), cx, model.state === 'preparing' || live || up || (model.state === 'error' && model.id) ? cy + 150 : cy + 10, 30, '#ffffff', { literal: true, align: 'center' });
            // bottom: the progress bar (the track, the part played, the scrubber) and the times
            if (model.total > 0 && live) {
                cv.gradientRect(0, SH - 150, SW, 150, [[0, '#00000000'], [1, '#000000d8']]);
                const x0 = LX + 40, w = SW - x0 - 40, y = SH - 66, el = shownAt(), fx = x0 + Math.round(w * Math.min(1, el / model.total)), bf = focusKey === 'ov:bar';
                const at = (ms) => x0 + Math.round(w * Math.min(1, ms / model.total)), ex = model.extras && model.extras.id === model.id ? model.extras : null;
                cv.roundRect(x0, y, w, 6, 3, '#ffffff55');
                cv.roundRect(x0, y, fx - x0, 6, 3, C.red);
                if (ex) sbSegs(ex).forEach((g) => cv.fillRect(at(g[0]), y, Math.max(3, at(g[1]) - at(g[0])), 6, sbColor(g)));   // SponsorBlock: skipped green, asked yellow
                if (ex) ex.chapters.forEach((c) => { if (c[0] > 0) cv.fillRect(at(c[0]) - 2, y, 4, 6, '#000000'); });
                if (bf) cv.circle(fx, y + 3, 18, '#ffffff');
                cv.circle(fx, y + 3, bf ? 14 : 10, C.red);
                tg(x0 - 10, y - 34, w + 20, 70, run(() => model.toggle()), 'ov:bar', 0, turnSeek);
                const tt0 = clock(el) + ' / ' + clock(model.total), tw = cv.textWidth(tt0, 24, LITB), chap = model.chapter();
                cv.text(tt0, x0, SH - 22, 24, '#ffffff', LITB);
                if (chap) cv.text(fit(cv, '·  ' + chap, 24, w - tw - 20, LIT), x0 + tw + 14, SH - 22, 24, '#dddddd', LIT);
            }
            if (model.toast && Date.now() < model.toast.until && live) {
                const tt = model.toast.text, tw2 = cv.textWidth(tt, 24, LIT) + 48, wn = model.toast.warn;
                cv.roundRect(LX + 40, SH - 150, tw2, 50, 25, wn ? '#4a3a10e6' : '#1f3d1fe6');
                cv.text(tt, LX + 64, SH - 116, 24, wn ? '#ffd27a' : '#7ee07e', LIT);
            }
            const ask = live && askSeg();
            if (ask) {
                const tt = 'Skip ' + sbName(ask[2]), w2 = cv.textWidth(tt, 28, LITB) + 70, sx = SW - 60 - w2, sy = SH - 168, f = focusKey === 'ov:sbskip';
                cv.roundRect(sx, sy, w2, 60, 30, f ? '#ffffff' : '#3a3a3ae6');
                cv.text(tt, sx + 35, sy + 40, 28, f ? '#0f0f0f' : '#ffffff', LITB);
                tg(sx, sy, w2, 60, run(sbJump(ask)), 'ov:sbskip', 30);
            }
            hmiIcons(cv);
        }
        // the HMI's home and back arrow column: its taps stay the HMI's, but no black hole over the video;
        // the same two icons where the HMI has them (screen px), on the scrim
        function hmiIcons(cv) {
            cv.xf(1, 0, 0);
            cv.circle(44, 42, 30, '#00000099');
            RAIL[1][2](cv, 44, 44, '#ffffff', '#1a1a1a');
            cv.circle(52, 398, 30, '#00000099');
            cv.polyline([[60, 384], [46, 398], [60, 412]], 5, '#ffffff');
            cv.xf();
        }
        let last = null, lastRev = -1, lastT = 0, upNext = null;
        function render() {
            if (keyboardBusy || exited) return Promise.resolve();
            const now = Date.now();
            upNext = autoNext();
            // redraw on a change (and 4 times a second); unchanged, the same frame again keeps the layer alive (>= 1 message/s)
            if (!last || dirty || model.rev !== lastRev || now - lastT > 250) {
                dirty = false; lastRev = model.rev; lastT = now;
                const cv = ctx.canvas(W, H).clear(C.bg);
                frameNo++;
                if (mode === 'player' && cv.own && cv.place && cv.place.full) drawFull(cv);
                else {
                    if (browsing()) drawRail(cv);
                    if (mode === 'player') drawPlayer(cv); else if (mode === 'channel') drawChannel(cv); else if (mode === 'results') drawResults(cv); else drawFeed(cv, isFeed(mode) ? mode : 'home');
                    // where the kit runs the screen the rail has the pages: the header shows just the name
                    if (cv.own) G.frame(cv, ctx.theme(), [], -1); else G.frame(cv, ctx.theme(), TABS.map((m) => NAMES[m]), TABS.indexOf(mode));
                }
                const actions = mode === 'player' ? [['Back', () => backToBrowse(), 'back']] :
                    [['Search',openSearch,'search'],['Settings',openSettings,'settings'],['Exit',exitApp,'exit']];
                actions.forEach(([label,action,key],i) => {
                    const x=mode==='player'?32:W-404+i*132, y=TOP+8;
                    cv.roundRect(x,y,124,44,10,focusKey==='action:'+key?C.red:C.card);
                    cv.text(label,x+62,y+29,22,C.text,{literal:true,align:'center',font:'bold'});
                    if(cv.own) cv.target(x,y,124,44,action,'action:'+key,10,undefined,1);
                });
                last = cv;
            }
            return ui.image('VIEW_GFX', last);
        }
        ctx.loop('VIEW', 10, render);
        log.info('iYT app started');
    },
});
